using System.Runtime.InteropServices;
using LighthousePrintServer.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var builder = Host.CreateApplicationBuilder(args);

#if WINDOWS
if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
    builder.Services.AddSingleton<IPrinterService, WindowsPrinterService>();
else
#endif
if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux) ||
    RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
    builder.Services.AddSingleton<IPrinterService, CupsPrinterService>();
else
    throw new PlatformNotSupportedException(
        "LighthousePrintServer only supports Windows, Linux, and macOS.");

builder.Logging.ClearProviders();
builder.Logging.AddConsole();

builder.Services.AddHostedService<HubConnectionService>();

var app = builder.Build();
app.Run();
