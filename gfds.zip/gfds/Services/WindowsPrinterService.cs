using System.Management;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security.Principal;
using LighthousePrintServer.Protos;

namespace LighthousePrintServer.Services
{
    [SupportedOSPlatform("windows")]
    public sealed class WindowsPrinterService : IPrinterService
    {
        private static ManagementObjectCollection QueryWmi(string wql)
        {
            using var searcher = new ManagementObjectSearcher(wql);
            return searcher.Get();
        }
        public async Task<(bool Success, string JobId, string Message)> AddDocumentAsync(string printerId, string documentName, byte[] documentData, string contentType, int copies, CancellationToken ct = default)
        {
            var tmpFile = Path.Combine(Path.GetTempPath(), $"lps_{Guid.NewGuid():N}.tmp");
            try
            {
                await File.WriteAllBytesAsync(tmpFile, documentData, ct);
                using var proc = new System.Diagnostics.Process
                {
                    StartInfo = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = tmpFile,
                        Verb = "printto",
                        Arguments = $"\"{printerId}\"",
                        UseShellExecute = true,
                        WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden,
                    }
                };
                proc.Start();
                await proc.WaitForExitAsync(ct);
                return (true, Guid.NewGuid().ToString("N")[..8], "Document spooled.");
            }
            catch (Exception ex)
            {
                return (false, string.Empty, ex.Message);
            }
            finally
            {
                await Task.Delay(2000, ct);
                if (File.Exists(tmpFile)) File.Delete(tmpFile);
            }
        }

        public Task<(bool Success, string Message)> ClearPrintQueueAsync(string printerId, CancellationToken ct = default)
        {
            try
            {
                var safe = printerId.Replace("'", "\\'");
                using var col = QueryWmi($"SELECT * FROM Win32_PrintJob WHERE Name LIKE '{safe},%'");
                foreach (ManagementObject obj in col)
                    obj.Delete();
                return Task.FromResult((true, "Queue cleared."));
            }
            catch (Exception ex)
            {
                return Task.FromResult((false, ex.Message));
            }
        }

        public Task<IReadOnlyList<PrinterInfo>> GetPrintersAsync(CancellationToken ct = default)
        {
            var results = new List<PrinterInfo>();
            using var col = QueryWmi("SELECT * FROM Win32_Printer");
            foreach (ManagementObject obj in col)
            {
                var id = obj["Name"]?.ToString() ?? string.Empty;
                var isDefault = obj["Default"] is bool d && d;
                var isPaused = obj["WorkOffline"] is bool p && p;
                var rawStatus = Convert.ToInt32(obj["PrinterStatus"] ?? 2);
                var status = isPaused ? PrinterStatus.Paused : rawStatus switch
                {
                    3 => PrinterStatus.Idle,
                    4 => PrinterStatus.Printing,
                    1 or 6 or 7 => PrinterStatus.Paused,
                    _ => PrinterStatus.Error
                };
                results.Add(new PrinterInfo
                {
                    PrinterId = id,
                    DisplayName = id,
                    IsDefault = isDefault,
                    Status = status,
                    IsPaused = isPaused,
                });
            }
            return Task.FromResult<IReadOnlyList<PrinterInfo>>(results);
        }

        public Task<IReadOnlyList<PrintJob>> GetPrintQueueAsync(string printerId, CancellationToken ct = default)
        {
            var jobs = new List<PrintJob>();
            var safe = printerId.Replace("'", "\\'");
            using var col = QueryWmi($"SELECT * FROM Win32_PrintJob WHERE Name LIKE '{safe},%'");
            foreach (ManagementObject obj in col)
            {
                var fullName = obj["Name"]?.ToString() ?? string.Empty;
                var jobId = fullName.Contains(',')
                               ? fullName[(fullName.LastIndexOf(',') + 1)..]
                               : fullName;
                var docName = obj["Document"]?.ToString() ?? string.Empty;
                var owner = obj["Owner"]?.ToString() ?? string.Empty;
                var pages = Convert.ToInt32(obj["TotalPages"] ?? 0);
                var statusRaw = Convert.ToUInt32(obj["StatusMask"] ?? 0u);
                var status = (statusRaw & 0x0001) != 0 ? JobStatus.Paused
                             : (statusRaw & 0x0010) != 0 ? JobStatus.Printing
                             : JobStatus.Pending;
                long submittedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                if (obj["TimeSubmitted"] is string wmiTime)
                    submittedAt = new DateTimeOffset(ManagementDateTimeConverter.ToDateTime(wmiTime))
                        .ToUnixTimeMilliseconds();

                jobs.Add(new PrintJob
                {
                    JobId = jobId,
                    DocumentName = docName,
                    Owner = owner,
                    Pages = pages,
                    Status = status,
                    SubmittedAt = submittedAt,
                });
            }
            return Task.FromResult<IReadOnlyList<PrintJob>>(jobs);
        }

        public Task<(bool Success, string Message)> PausePrinterAsync(string printerId, CancellationToken ct = default)
        {
            return Task.FromResult(SetPrinterControl(printerId, PRINTER_CONTROL_PAUSE));
        }

        public Task<(bool Success, string Message)> RemoveDocumentAsync(string printerId, string jobId, CancellationToken ct = default)
        {
            try
            {
                var safe = printerId.Replace("'", "\\'");
                using var col = QueryWmi(
                    $"SELECT * FROM Win32_PrintJob WHERE Name = '{safe},{jobId}'");
                foreach (ManagementObject obj in col)
                    obj.Delete();
                return Task.FromResult((true, "Job removed."));
            }
            catch (Exception ex)
            {
                return Task.FromResult((false, ex.Message));
            }
        }

        public Task<(bool Success, string Message)> ResumePrinterAsync(string printerId, CancellationToken ct = default)
        {
            return Task.FromResult(SetPrinterControl(printerId, PRINTER_CONTROL_RESUME));
        }



        private (bool Success, string Message) SetPrinterControl(string printerId, int command)
        {
            var identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            Console.WriteLine($"[DEBUG] Current user: {identity.Name}");
            Console.WriteLine($"[DEBUG] Is admin: {principal.IsInRole(WindowsBuiltInRole.Administrator)}");
            Console.WriteLine($"[DEBUG] Is elevated: {identity.Owner == identity.User}");

            var defaults = new PRINTER_DEFAULTS
            {
                pDatatype = IntPtr.Zero,
                pDevMode = IntPtr.Zero,
                DesiredAccess = PRINTER_ALL_ACCESS,
            };

            Console.WriteLine($"[DEBUG] Calling OpenPrinter for '{printerId}' with PRINTER_ALL_ACCESS (0x{PRINTER_ALL_ACCESS:X})");
            if (!OpenPrinter(printerId, out var hPrinter, ref defaults))
            {
                var err = Marshal.GetLastWin32Error();
                Console.WriteLine($"[DEBUG] OpenPrinter failed: error {err}");
                return (false, $"OpenPrinter failed: error {err}");
            }

            Console.WriteLine($"[DEBUG] OpenPrinter succeeded, handle=0x{hPrinter:X}. Calling SetPrinter command={command}");
            try
            {
                bool ok = SetPrinter(hPrinter, 0, IntPtr.Zero, command);
                var err = Marshal.GetLastWin32Error();
                Console.WriteLine($"[DEBUG] SetPrinter returned {ok}, last error={err}");
                return ok
                    ? (true, command == PRINTER_CONTROL_PAUSE ? "Printer paused." : "Printer resumed.")
                    : (false, $"SetPrinter failed: error {err}");
            }
            finally
            {
                ClosePrinter(hPrinter);
            }
        }



















        // weirrd windows stuff
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct PRINTER_DEFAULTS
        {
            public IntPtr pDatatype;
            public IntPtr pDevMode;
            public int DesiredAccess;
        }

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool OpenPrinter(string printerName, out IntPtr hPrinter, ref PRINTER_DEFAULTS pDefault);

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool SetPrinter(IntPtr hPrinter, int level, IntPtr pPrinter, int command);

        [DllImport("winspool.drv", SetLastError = true)]
        private static extern bool ClosePrinter(IntPtr hPrinter);

        private const int PRINTER_CONTROL_PAUSE = 1;
        private const int PRINTER_CONTROL_RESUME = 2;
        private const int PRINTER_ACCESS_ADMINISTER = 0x4;
        private const int PRINTER_ACCESS_USE = 0x8;
        private const int STANDARD_RIGHTS_REQUIRED = 0x000F0000;
        private const int PRINTER_ALL_ACCESS = STANDARD_RIGHTS_REQUIRED | PRINTER_ACCESS_ADMINISTER | PRINTER_ACCESS_USE;

    }
}