using LighthousePrintServer.Protos;

namespace LighthousePrintServer.Services;

public interface IPrinterService
{
    Task<IReadOnlyList<PrinterInfo>> GetPrintersAsync(
        CancellationToken ct = default);

    Task<IReadOnlyList<PrintJob>> GetPrintQueueAsync(
        string printerId,
        CancellationToken ct = default);

    Task<(bool Success, string Message)> ClearPrintQueueAsync(
        string printerId,
        CancellationToken ct = default);

    Task<(bool Success, string JobId, string Message)> AddDocumentAsync(
        string printerId,
        string documentName,
        byte[] documentData,
        string contentType,
        int copies,
        CancellationToken ct = default);

    Task<(bool Success, string Message)> RemoveDocumentAsync(
        string printerId,
        string jobId,
        CancellationToken ct = default);

    Task<(bool Success, string Message)> PausePrinterAsync(
        string printerId,
        CancellationToken ct = default);

    Task<(bool Success, string Message)> ResumePrinterAsync(
        string printerId,
        CancellationToken ct = default);
}
