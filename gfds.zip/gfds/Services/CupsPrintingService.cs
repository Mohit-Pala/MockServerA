using System.Diagnostics;
using System.Text.RegularExpressions;
using LighthousePrintServer.Protos;

namespace LighthousePrintServer.Services;

public sealed class CupsPrinterService : IPrinterService
{
    private static async Task<(int ExitCode, string Stdout, string Stderr)> RunAsync(string cmd, string args, CancellationToken ct)
    {
        using var proc = new Process
        {
            StartInfo = new ProcessStartInfo(cmd, args)
            {
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                UseShellExecute        = false,
                CreateNoWindow         = true,
            }
        };
        proc.Start();
        var stdout = await proc.StandardOutput.ReadToEndAsync(ct);
        var stderr = await proc.StandardError.ReadToEndAsync(ct);
        await proc.WaitForExitAsync(ct);
        return (proc.ExitCode, stdout, stderr);
    }

    public async Task<(bool Success, string JobId, string Message)> AddDocumentAsync(string printerId, string documentName, byte[] documentData, string contentType, int copies, CancellationToken ct = default)
    {
        var tmpFile = Path.Combine(Path.GetTempPath(), $"lps_{Guid.NewGuid():N}.tmp");
        try
        {
            await File.WriteAllBytesAsync(tmpFile, documentData, ct);
            var args = $"-d {printerId} -n {Math.Max(1, copies)} -t \"{documentName}\" {tmpFile}";
            var (exit, stdout, stderr) = await RunAsync("lp", args, ct);
            if (exit != 0) return (false, string.Empty, stderr.Trim());

            var jobId = Regex.Match(stdout, @"request id is \S+-(\d+)").Groups[1].Value;
            return (true, jobId, "Document queued.");
        }
        finally
        {
            if (File.Exists(tmpFile)) File.Delete(tmpFile);
        }
    }

    public async Task<(bool Success, string Message)> ClearPrintQueueAsync(string printerId, CancellationToken ct = default)
    {
        var (exit, _, stderr) = await RunAsync("cancel", $"-a {printerId}", ct);
        return exit == 0 ? (true, "Queue cleared.") : (false, stderr.Trim());
    }

    public async Task<IReadOnlyList<PrinterInfo>> GetPrintersAsync(CancellationToken ct = default)
    {
        var (_, acceptOut, _) = await RunAsync("lpstat", "-a", ct);
        var (_, statusOut, _) = await RunAsync("lpstat", "-p", ct);
        var (_, defaultOut, _) = await RunAsync("lpstat", "-d", ct);

        var defaultPrinter = Regex.Match(defaultOut, @"system default destination:\s+(\S+)")
                                   .Groups[1].Value.Trim();

        var statusMap = new Dictionary<string, (PrinterStatus Status, bool IsPaused)>(StringComparer.OrdinalIgnoreCase);
        foreach (var line in statusOut.Split('\n'))
        {
            var m = Regex.Match(line, @"^printer\s+(\S+)\s+is\s+(\w+)");
            if (!m.Success) continue;
            var name  = m.Groups[1].Value;
            var rawSt = m.Groups[2].Value.ToLower();
            var status = rawSt switch
            {
                "idle"     => PrinterStatus.Idle,
                "printing" => PrinterStatus.Printing,
                "paused"   => PrinterStatus.Paused,
                _          => PrinterStatus.Error
            };
            statusMap[name] = (status, rawSt == "paused");
        }

        var results = new List<PrinterInfo>();
        foreach (var line in acceptOut.Split('\n'))
        {
            var parts = line.Split(' ', 2);
            if (parts.Length == 0 || string.IsNullOrWhiteSpace(parts[0])) continue;
            var id = parts[0].Trim();
            var (status, isPaused) = statusMap.TryGetValue(id, out var s) ? s : (PrinterStatus.Idle, false);
            results.Add(new PrinterInfo
            {
                PrinterId   = id,
                DisplayName = id,
                IsDefault   = id == defaultPrinter,
                Status      = status,
                IsPaused    = isPaused,
            });
        }
        return results;
    }

    public async Task<IReadOnlyList<PrintJob>> GetPrintQueueAsync(string printerId, CancellationToken ct = default)
    {
        var (_, stdout, _) = await RunAsync("lpstat", $"-o {printerId}", ct);
        var jobs = new List<PrintJob>();
        foreach (var line in stdout.Split('\n'))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            var m = Regex.Match(line, @"^(\S+)-(\d+)\s+(\S+)\s+\d+\s+(.+)$");
            if (!m.Success) continue;
            var jobId   = m.Groups[2].Value;
            var owner   = m.Groups[3].Value;
            var docName = $"{printerId}-{jobId}";
            jobs.Add(new PrintJob
            {
                JobId        = jobId,
                DocumentName = docName,
                Owner        = owner,
                Pages        = 0,
                Status       = JobStatus.Pending,
                SubmittedAt  = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            });
        }
        return jobs;
    }

    public async Task<(bool Success, string Message)> PausePrinterAsync(string printerId, CancellationToken ct = default)
    {
        var (exit, _, stderr) = await RunAsync("cupsdisable", printerId, ct);
        return exit == 0 ? (true, "Printer paused.") : (false, stderr.Trim());
    }

    public async Task<(bool Success, string Message)> RemoveDocumentAsync(string printerId, string jobId, CancellationToken ct = default)
    {
        var (exit, _, stderr) = await RunAsync("cancel", $"{printerId}-{jobId}", ct);
        return exit == 0 ? (true, "Job cancelled.") : (false, stderr.Trim());
    }

    public async Task<(bool Success, string Message)> ResumePrinterAsync(string printerId, CancellationToken ct = default)
    {
        var (exit, _, stderr) = await RunAsync("cupsenable", printerId, ct);
        return exit == 0 ? (true, "Printer resumed.") : (false, stderr.Trim());        
    }
}