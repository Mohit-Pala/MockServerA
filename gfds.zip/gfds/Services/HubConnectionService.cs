using System.Runtime.InteropServices;
using System.Text.Json;
using DeviceId;
using Grpc.Core;
using Grpc.Net.Client;
using LighthousePrintServer.Protos;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace LighthousePrintServer.Services;

public class HubConnectionService : BackgroundService
{
    private readonly IPrinterService _printerService;
    private readonly ILogger<HubConnectionService> _logger;
    private readonly string _hubAddress;

    public HubConnectionService(IPrinterService printerService, ILogger<HubConnectionService> logger)
    {
        _printerService = printerService;
        _logger = logger;
        _hubAddress = Environment.GetEnvironmentVariable("LIGHTHOUSEAPI_PRINTHUB_ADDRESS") ?? "http://localhost:6060";
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ConnectAndHandleAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (RpcException ex) when (ex.StatusCode == StatusCode.Unavailable)
            {
                _logger.LogWarning("Hub unavailable, retrying in 5s...");
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Hub connection error, retrying in 5s...");
                await Task.Delay(TimeSpan.FromSeconds(5), stoppingToken);
            }
        }
    }

    private async Task ConnectAndHandleAsync(CancellationToken ct)
    {
        AppContext.SetSwitch("System.Net.Http.SocketsHttpHandler.Http2UnencryptedSupport", true);
        using var channel = GrpcChannel.ForAddress(_hubAddress, new GrpcChannelOptions
        {
            HttpHandler = new SocketsHttpHandler
            {
                EnableMultipleHttp2Connections = true
            }
        });
        var client = new PrintServerHub.PrintServerHubClient(channel);

        using var stream = client.Connect(cancellationToken: ct);

        var machineId = new DeviceIdBuilder()
            .AddMachineName()
            .AddOsVersion()
            .ToString();
        
        var printers = await _printerService.GetPrintersAsync(ct);

        var registerRequest = new RegisterRequest
        {
            MachineId = machineId,
            Hostname  = Environment.MachineName,
        };
        registerRequest.Printers.AddRange(printers);

        await stream.RequestStream.WriteAsync(new PrintServerMessage { Register = registerRequest }, ct);

        _logger.LogInformation("Connected to hub at {Address} — machine={MachineId} host={Hostname} printers={Count}",
            _hubAddress, machineId, Environment.MachineName, printers.Count);

        // Start heartbeat in background
        var heartbeatTask = SendHeartbeatsAsync(stream.RequestStream, ct);

        await foreach (var msg in stream.ResponseStream.ReadAllAsync(ct))
        {
            switch (msg.PayloadCase)
            {
                case HubMessage.PayloadOneofCase.RegRes:
                    _logger.LogInformation("Hub: accepted={Accepted} message={Message}",
                        msg.RegRes.Accepted, msg.RegRes.Message);
                    break;

                case HubMessage.PayloadOneofCase.Command:
                    _ = HandleCommandAsync(msg.Command, stream.RequestStream, ct);
                    break;
            }
        }

        await heartbeatTask;
    }

    private async Task SendHeartbeatsAsync(IClientStreamWriter<PrintServerMessage> writer, CancellationToken ct)
    {
        try
        {
            while (!ct.IsCancellationRequested)
            {
                await Task.Delay(TimeSpan.FromSeconds(30), ct);
                await writer.WriteAsync(new PrintServerMessage { Heartbeat = new Heartbeat() }, ct);
            }
        }
        catch (OperationCanceledException) { }
    }

    private async Task HandleCommandAsync(
        HubCommand command,
        IClientStreamWriter<PrintServerMessage> writer,
        CancellationToken ct)
    {
        _logger.LogInformation("Received command {Type} (id={CommandId})", command.Type, command.CommandId);

        try
        {
            var (success, error, payload) = command.Type switch
            {
                HubCommandType.HubCommandGetPrinters => await GetPrintersAsync(ct),
                HubCommandType.HubCommandGetQueue => await GetQueueAsync(command.PrinterId, ct),
                HubCommandType.HubCommandPausePrinter => await PausePrinterAsync(command.PrinterId, ct),
                HubCommandType.HubCommandResumePrinter => await ResumePrinterAsync(command.PrinterId, ct),
                HubCommandType.HubCommandClearQueue => await ClearQueueAsync(command.PrinterId, ct),
                HubCommandType.HubCommandAddDocument => await AddDocumentAsync(command, ct),
                HubCommandType.HubCommandRemoveDocument => await RemoveDocumentAsync(command.PrinterId, command.JobId, ct),
                _ => (false, $"Unknown command type: {command.Type}", null)
            };

            await writer.WriteAsync(new PrintServerMessage
            {
                Response = new CommandResponse
                {
                    CommandId = command.CommandId,
                    Success = success,
                    Error = error ?? "",
                    Payload = payload != null
                        ? Google.Protobuf.ByteString.CopyFromUtf8(payload)
                        : Google.Protobuf.ByteString.Empty
                }
            }, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error handling command {CommandId}", command.CommandId);
            await writer.WriteAsync(new PrintServerMessage
            {
                Response = new CommandResponse
                {
                    CommandId = command.CommandId,
                    Success = false,
                    Error = ex.Message
                }
            }, ct);
        }
    }

    private async Task<(bool, string?, string?)> GetPrintersAsync(CancellationToken ct)
    {
        var printers = await _printerService.GetPrintersAsync(ct);
        var json = JsonSerializer.Serialize(printers.Select(p => new
        {
            p.PrinterId,
            p.DisplayName,
            p.IsDefault,
            Status = p.Status.ToString(),
            p.IsPaused
        }));
        return (true, null, json);
    }

    private async Task<(bool, string?, string?)> GetQueueAsync(string printerId, CancellationToken ct)
    {
        var jobs = await _printerService.GetPrintQueueAsync(printerId, ct);
        var json = JsonSerializer.Serialize(jobs.Select(j => new
        {
            j.JobId,
            j.DocumentName,
            j.Owner,
            j.Pages,
            Status = j.Status.ToString(),
            j.SubmittedAt
        }));
        return (true, null, json);
    }

    private async Task<(bool, string?, string?)> PausePrinterAsync(string printerId, CancellationToken ct)
    {
        var (success, message) = await _printerService.PausePrinterAsync(printerId, ct);
        return (success, success ? null : message, null);
    }

    private async Task<(bool, string?, string?)> ResumePrinterAsync(string printerId, CancellationToken ct)
    {
        var (success, message) = await _printerService.ResumePrinterAsync(printerId, ct);
        return (success, success ? null : message, null);
    }

    private async Task<(bool, string?, string?)> ClearQueueAsync(string printerId, CancellationToken ct)
    {
        var (success, message) = await _printerService.ClearPrintQueueAsync(printerId, ct);
        return (success, success ? null : message, null);
    }

    private async Task<(bool, string?, string?)> AddDocumentAsync(HubCommand command, CancellationToken ct)
    {
        var (success, jobId, message) = await _printerService.AddDocumentAsync(
            command.PrinterId,
            command.DocumentName,
            command.DocumentData.ToByteArray(),
            command.ContentType,
            command.Copies == 0 ? 1 : command.Copies,
            ct);
        var payload = success ? JsonSerializer.Serialize(new { JobId = jobId }) : null;
        return (success, success ? null : message, payload);
    }

    private async Task<(bool, string?, string?)> RemoveDocumentAsync(string printerId, string jobId, CancellationToken ct)
    {
        var (success, message) = await _printerService.RemoveDocumentAsync(printerId, jobId, ct);
        return (success, success ? null : message, null);
    }
}
